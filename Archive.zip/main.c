
#include <stdio.h>
#include "unified_voice.h"
#include "pml_logic_loop.h"

int main() {
    printf("Testing unified voice and PML logic loop modules.\n");

    io_socket_t socket;
    init_unified_voice(&socket, 1);

    PMLL pmll_instance;
    pml_logic_loop_init(&pmll_instance, 1, 2);
    pml_logic_loop_process(&pmll_instance, NULL, 0);
    pml_logic_loop_cleanup(&pmll_instance);

    cleanup_unified_voice(&socket, NULL, NULL);

    printf("All modules tested successfully.\n");
    return 0;
}
