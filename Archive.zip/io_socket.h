
#ifndef IO_SOCKET_H
#define IO_SOCKET_H

#include <stddef.h> // For size_t

// Constants
#define SERVER_IP "127.0.0.1"       // Default server IP
#define SERVER_PORT 8080            // Default server port
#define BUFFER_SIZE 1024            // Default buffer size
#define RETRY_LIMIT 5               // Maximum number of connection retries

// Define io_socket_t as a placeholder for socket handling
typedef struct io_socket_t {
    int socket_fd; // File descriptor for the socket
    char ip_address[16]; // IPv4 address as a string
    int port; // Port number
} io_socket_t;

// Function Declarations
void io_socket_init(io_socket_t* socket, const char* ip, int port);
void io_socket_cleanup(io_socket_t* socket);

#endif // IO_SOCKET_H
